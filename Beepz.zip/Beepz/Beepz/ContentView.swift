//
//  ContentView.swift
//  Beepz
//
//  Created by Macbook Pro 2015 on 15/1/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ScrollView{
            VStack{
                VStack{
                    Image(systemName: "sunset.fill")
                        .renderingMode(.original)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 30, height: 30)
                    Text("Beepz")
                        .font(.system(size:20 , weight : .bold))
                       
                }
                VStack{
                    
                    HStack{
                        Spacer()
                        Image(systemName: "sunset.fill")
                            .renderingMode(.original)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 30, height: 30)
                        
                        VStack{
                            HStack{
                                Text("Order Number")
                                    .font(.system(size:20 , weight: .bold))
                                Spacer()
                            }
                            HStack{
                                Text("#375485")
                                Spacer()
                            }
                        }
                    }.frame(width: 200, height: 100 , alignment: .center).background(Color.blue).cornerRadius(20)
                    
                }
                
                ExtractedView(firstText: "Booking Comfirmed", secondText: "you are putting that monkey in the", imageName: "cloud.sun.fill")
                ExtractedView(firstText: "Driver On the way to pickup", secondText: "you are putting that monkey in the", imageName: "cloud.sun.fill")
                ExtractedView(firstText: "QR Code Scaned", secondText: "you are putting that monkey in the", imageName: "cloud.sun.fill")
                ExtractedView(firstText: "Car Picked Up", secondText: "you are putting that monkey in the", imageName: "cloud.sun.fill")
                ExtractedView(firstText: "Reached Garage", secondText: "you are putting that monkey in the", imageName: "cloud.sun.fill")
                ExtractedView(firstText: "Service Started", secondText: "you are putting that monkey in the", imageName: "cloud.sun.fill")
                ExtractedView(firstText: "Service Ended", secondText: "you are putting that monkey in the", imageName: "cloud.sun.fill")
                ExtractedView(firstText: "Driver On the way to Drop Off", secondText: "you are putting that monkey in the", imageName: "cloud.sun.fill")
                
            }
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
struct ExtractedView: View {
    var firstText : String
    var secondText : String
    var imageName : String
    var body: some View {
        HStack(spacing : 16){
            
            Spacer(minLength: 70)
            VStack(spacing : 8){
                Image(systemName: imageName)
                    .renderingMode(.original)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 30, height: 30)
            }
            VStack{
                HStack{
                    Text(firstText)
                        .font(.system(size: 16, weight: .bold, design: .default))
                    Spacer()
                }
                HStack{
                    Text(secondText)
                        .font(.system(size: 14 , weight : .medium , design : .default))
                    Spacer()
                }
            }
            
            
            
        }
    }
}
