//
//  BeepzApp.swift
//  Beepz
//
//  Created by Macbook Pro 2015 on 15/1/22.
//

import SwiftUI

@main
struct BeepzApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
